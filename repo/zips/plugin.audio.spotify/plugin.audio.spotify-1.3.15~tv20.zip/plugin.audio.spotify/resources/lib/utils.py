import inspect
import os
import platform
import signal
import sys
import time
import unicodedata
from traceback import format_exception
from typing import Any, Dict, List, Tuple, Union

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
from xbmc import LOGDEBUG, LOGINFO, LOGERROR

DEBUG = True
PROXY_PORT = 52308

ADDON_ID = "plugin.audio.spotify"
ADDON_DATA_PATH = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}")
ADDON_WINDOW_ID = 10000

KODI_PROPERTY_SPOTIFY_AUTH_TOKEN = "spotify-auth-token"
KODI_PROPERTY_AUTH_TOKEN_EXPIRES_AT = "spotify-auth-token-expires-at"
# token of the user's own client id (optional), see spotify_client.py
KODI_PROPERTY_SPOTIFY_OWN_AUTH_TOKEN = "spotify-own-auth-token"
OWN_CLIENT_ID_SETTING = "user_client_id"
PRELOAD_PLAYLISTS_SETTING = "preload_playlists"


def log_msg(msg: str, loglevel: int = LOGDEBUG, caller_name: str = "") -> None:
    if DEBUG and (loglevel == LOGDEBUG):
        loglevel = LOGINFO
    if not caller_name:
        caller_name = get_formatted_caller_name(inspect.stack()[1][1], inspect.stack()[1][3])

    xbmc.log(f"{ADDON_ID}:{caller_name}: {msg}", level=loglevel)


def log_exception(exc: Exception, exception_details: str) -> None:
    the_caller_name = get_formatted_caller_name(inspect.stack()[1][1], inspect.stack()[1][3])
    # the single argument form needs Python 3.10, Kodi on Windows has 3.8
    lines = format_exception(type(exc), exc, exc.__traceback__)
    log_msg(" ".join(lines), loglevel=LOGERROR, caller_name=the_caller_name)
    log_msg(f"Exception --> {exception_details}.", loglevel=LOGERROR, caller_name=the_caller_name)


def get_formatted_caller_name(filename: str, function_name: str) -> str:
    return f"{os.path.splitext(os.path.basename(filename))[0]}:{function_name}"


def stop_video_playback(timeout: float = 5.0) -> None:
    """
    Stop a playing video before a track is started. Tracks are played by the
    VideoPlayer (see http_video_player_setter.py), and Kodi would play them in
    the running video player, which keeps behaving as if a video was playing
    (fullscreen video window, video OSD, refresh rate of the video).
    """
    if not xbmc.getCondVisibility("Player.HasVideo"):
        return
    log_msg("Stopping the playing video before playing a track.", LOGINFO)
    xbmc.Player().stop()
    monitor = xbmc.Monitor()
    end_time = time.time() + timeout
    while xbmc.getCondVisibility("Player.HasMedia") and time.time() < end_time:
        if monitor.waitForAbort(0.1):
            return
    # Kodi drops a play request while the stopped player is still closing
    monitor.waitForAbort(0.5)


def get_time_str(raw_time: int) -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(float(raw_time)))


def get_username() -> str:
    addon = xbmcaddon.Addon(id=ADDON_ID)
    spotify_username = addon.getSetting("username")
    if not spotify_username:
        raise Exception("Could not get spotify username.")
    return spotify_username


def kill_this_plugin() -> None:
    sys.exit(1)


def kill_process_by_pid(pid: int) -> None:
    try:
        if platform.system() != "Windows":
            os.kill(pid, signal.SIGKILL)
    except OSError:
        pass


def bytes_to_megabytes(byts: int) -> float:
    return (byts / 1024.0) / 1024.0


def get_chunks(data, chunk_size: int):
    return [data[x : x + chunk_size] for x in range(0, len(data), chunk_size)]


def try_encode(text, encoding="utf-8"):
    try:
        return text.encode(encoding, "ignore")
    except UnicodeEncodeError:
        return text


def try_decode(text, encoding="utf-8"):
    try:
        return text.decode(encoding, "ignore")
    except UnicodeDecodeError:
        return text


def normalize_string(text):
    text = text.replace(":", "")
    text = text.replace("/", "-")
    text = text.replace("\\", "-")
    text = text.replace("<", "")
    text = text.replace(">", "")
    text = text.replace("*", "")
    text = text.replace("?", "")
    text = text.replace("|", "")
    text = text.replace("(", "")
    text = text.replace(")", "")
    text = text.replace('"', "")
    text = text.strip()
    text = text.rstrip(".")
    text = unicodedata.normalize("NFKD", try_decode(text))

    return text


def cache_auth_token(auth_token: str) -> None:
    cache_value_in_kodi(KODI_PROPERTY_SPOTIFY_AUTH_TOKEN, auth_token)


def get_cached_auth_token() -> str:
    return get_cached_value_from_kodi(KODI_PROPERTY_SPOTIFY_AUTH_TOKEN)


def cache_own_auth_token(auth_token: str) -> None:
    cache_value_in_kodi(KODI_PROPERTY_SPOTIFY_OWN_AUTH_TOKEN, auth_token)


def get_own_auth_token() -> str:
    # Not waiting for it like for the shared token, there may be none.
    return xbmcgui.Window(ADDON_WINDOW_ID).getProperty(KODI_PROPERTY_SPOTIFY_OWN_AUTH_TOKEN)


def start_preloading_playlists() -> None:
    """Start preloading the playlists in the background, see PluginContent.preload_playlists"""
    if xbmcaddon.Addon(id=ADDON_ID).getSetting(PRELOAD_PLAYLISTS_SETTING) == "false":
        return
    xbmc.executebuiltin(f"RunPlugin(plugin://{ADDON_ID}/?action=preload_playlists)")


def get_own_client_id() -> str:
    client_id = xbmcaddon.Addon(id=ADDON_ID).getSetting(OWN_CLIENT_ID_SETTING)
    return "".join(client_id.split())


def cache_auth_token_expires_at(auth_token: str) -> None:
    cache_value_in_kodi(KODI_PROPERTY_AUTH_TOKEN_EXPIRES_AT, auth_token)


def get_cached_auth_token_expires_at() -> str:
    return get_cached_value_from_kodi(KODI_PROPERTY_AUTH_TOKEN_EXPIRES_AT)


def cache_value_in_kodi(kodi_property_id: str, value: Any):
    win = xbmcgui.Window(ADDON_WINDOW_ID)
    win.setProperty(kodi_property_id, value)


def get_cached_value_from_kodi(kodi_property_id: str, wait_ms: int = 500) -> Any:
    win = xbmcgui.Window(ADDON_WINDOW_ID)

    count = 10
    while count > 0:
        value = win.getProperty(kodi_property_id)
        if value:
            return value
        xbmc.sleep(wait_ms)
        count -= 1

    return None


def get_user_playlists(
    spotipy, limit: int = 50, offset: int = 0
) -> Tuple[List[Dict[str, Any]], List[str]]:
    userid = spotipy.me()["id"]
    playlists = spotipy.user_playlists(userid, limit=limit, offset=offset)

    own_playlists = []
    own_playlist_names = []
    for playlist in playlists["items"]:
        if playlist["owner"]["id"] == userid:
            own_playlists.append(playlist)
            own_playlist_names.append(playlist["name"])

    return own_playlists, own_playlist_names


def get_user_playlist_id(spotipy, playlist_name: str) -> Union[str, None]:
    offset = 0
    while True:
        own_playlists, own_playlist_names = get_user_playlists(spotipy, limit=50, offset=offset)
        if len(own_playlists) == 0:
            break
        for playlist in own_playlists:
            if playlist_name == playlist["name"]:
                return playlist["id"]
        offset += 50

    return None
