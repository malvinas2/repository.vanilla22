"""
HTTP server for Spotify audio streams. WAV (PCM) path only.
We serve standard HTTP range semantics so Kodi's cache/buffer settings take effect.
"""

import math
import re
import threading
import time
import uuid
from typing import Callable, Optional, Tuple

import bottle
import spotipy
import xbmc
import xbmcaddon
import xbmcgui
from like_actions import notify_not_connected, set_current_track_liked
from string_ids import (
    SPOTIFY_PLAYBACK_FAILED_STR_ID,
    SPOTIFY_PLAYBACK_AUTH_STR_ID,
    SPOTIFY_PLAYBACK_PREMIUM_STR_ID,
)
from spotty import Spotty
from spotty_audio_streamer import (
    STARTUP_REAL_PCM_WAIT_SECONDS,
    SpottyAudioStreamer,
    SpottyStreamSpec,
    create_wav_header_for_duration,
)
from utils import ADDON_ID, ADDON_WINDOW_ID, LOGDEBUG, get_valid_cached_auth_token, log_msg
from xbmc import LOGWARNING

_settings_cache = {
    "bitrate": "320",
    "normalization": "auto",
    "last_update_time": 0.0,
}
_settings_cache_lock = threading.Lock()
_SETTINGS_CACHE_TTL = 1.0  # Cache for 1 second
NATURAL_HANDOFF_REMAINING_SECONDS = 8.0
INITIALIZATION_WAIT_SECONDS = STARTUP_REAL_PCM_WAIT_SECONDS + 2.0
HEALTHY_PROGRESS_MAX_IDLE_SECONDS = 15.0


def _get_current_stream_settings():
    """Read addon settings with caching to avoid expensive xbmcaddon.Addon() creation.

    Returns (bitrate, normalization)
    """
    global _settings_cache, _settings_cache_lock

    current_time = time.time()
    with _settings_cache_lock:
        if current_time - _settings_cache["last_update_time"] < _SETTINGS_CACHE_TTL:
            return _settings_cache["bitrate"], _settings_cache["normalization"]

        try:
            addon = xbmcaddon.Addon(id=ADDON_ID)
            bitrate_raw = (addon.getSetting("spotify_bitrate") or "320").strip()
            bitrate = bitrate_raw if bitrate_raw in ("96", "160", "320") else "320"
            norm = (addon.getSetting("spotify_normalization") or "auto").strip().lower()
            if norm not in ("off", "auto", "track", "album"):
                norm = "auto"

            _settings_cache["bitrate"] = bitrate
            _settings_cache["normalization"] = norm
            _settings_cache["last_update_time"] = current_time
            return bitrate, norm
        except Exception:
            return _settings_cache["bitrate"], _settings_cache["normalization"]


def _parse_time_label(value: str) -> Optional[int]:
    parts = [part.strip() for part in (value or "").split(":") if part.strip()]
    if len(parts) < 2:
        return None

    try:
        seconds = 0
        for part in parts:
            seconds = seconds * 60 + int(part)
        return seconds
    except ValueError:
        return None


# No debounce: serve every range request immediately so Kodi's seek bar and
# Player.Progress update right away. Let Kodi drive; we just fulfill each request.


class HTTPSpottyAudioStreamer:
    def __init__(
        self,
        spotty: Spotty,
        normalization_gain_type: str = "auto",
        prebuffer_manager=None,
        on_track_started_callback: Optional[Callable[[str, float], None]] = None,
        use_autoplay: bool = False,
        bitrate: str = "320",
    ):
        self.__spotty: Spotty = spotty
        self.__prebuffer_manager = prebuffer_manager
        self.__on_track_started = on_track_started_callback or (lambda _id, _dur: None)
        self.__notify_track_finished: Callable[[str], None] = lambda _id: None

        self.__spotty_streamer: SpottyAudioStreamer = SpottyAudioStreamer(self.__spotty)
        self.__spotty_streamer.normalization_gain_type = (
            normalization_gain_type or "auto"
        ).strip().lower() or "auto"
        self.__spotty_streamer.use_autoplay = use_autoplay
        self.__spotty_streamer.bitrate = bitrate
        self.__is_streaming = False
        self.__stream_lock = threading.Lock()
        self._failure_notice_lock = threading.Lock()
        self._last_failure_notice = (None, 0.0)
        self.__current_track_id: Optional[str] = None
        self.__current_request_id: str = ""  # Track current request for init coordination.
        self.__current_stream_spec: Optional[SpottyStreamSpec] = None
        # Init coordination: when a new-track GET is being initialized, set this
        # so other concurrent GETs can wait and then reuse the same request id.
        self.__init_in_progress = False
        self.__initializing_track_id: Optional[str] = None
        self.__initializing_request_id: str = ""
        self.__init_event = threading.Event()
        self.__init_event.set()

    def set_normalization_gain_type(self, value: str) -> None:
        self.__spotty_streamer.normalization_gain_type = (value or "auto").strip().lower() or "auto"

    def set_notify_track_finished(self, func: Callable[[str], None]) -> None:
        self.__notify_track_finished = func or (lambda _id: None)
        self.__spotty_streamer.set_notify_track_finished(self.__notify_track_finished)

    def set_stream_ended(self, track_id: Optional[str] = None) -> None:
        """Mark that the current stream has finished so the next request starts fresh.

        Pass the track_id that just finished so we can ignore stale calls when a new
        track has already started (e.g. the old generator finishes *after* QueueNextFileEx
        has already transitioned __current_track_id to the next track).
        """
        with self.__stream_lock:
            if track_id is not None and self.__current_track_id != track_id:
                # A newer track is already loaded — don't clobber its __is_streaming flag.
                log_msg(
                    f"set_stream_ended: ignoring stale end for {track_id} "
                    f"(current={self.__current_track_id})",
                    LOGDEBUG,
                )
                return
            self.__is_streaming = False
            # Do NOT clear __current_track_id here. It must remain set so that
            # _previous_track_id is non-null when QueueNextFileEx fires after the
            # stream ends naturally (minutes before audio fully plays out of Kodi's
            # buffer), allowing _skip_terminate to correctly skip the terminate call.

    def is_current_track_streaming(self, track_id: str) -> bool:
        """Check if the given track is still being streamed to Kodi."""
        with self.__stream_lock:
            return self.__is_streaming and self.__current_track_id == track_id

    def set_on_track_started(self, func: Callable[[str, float], None]) -> None:
        self.__on_track_started = func or (lambda _id, _dur: None)

    def set_prebuffer_manager(self, manager) -> None:
        self.__prebuffer_manager = manager

    def stop(self) -> None:
        log_msg("Stopping spotty audio streaming.", LOGDEBUG)
        if self.__is_streaming:
            self.__terminate_streaming()
        else:
            log_msg("No running audio streamer. Nothing to stop.", LOGDEBUG)

    def release_stream(self, release_resources: Callable[[Optional[SpottyStreamSpec]], bool]) -> bool:
        """Drop the active stream and run release_resources with new requests held.

        The release owns the initialization reservation while release_resources
        runs, so a request that arrives meanwhile waits and then starts fresh
        with a new playback generation. The callback may retain eligible PCM.

        A stream startup in progress belongs to a newer selection: Kodi waits for
        a closing player's stream requests before reporting the stop.  The
        release then leaves the stream state and all resources alone.

        Return whether the release found playback or retained resources.
        """
        release_id = f"release-{uuid.uuid4()}"
        with self.__stream_lock:
            if self.__init_in_progress:
                return False
            released_track = self.__current_track_id is not None
            released_spec = self.__current_stream_spec
            self.__is_streaming = False
            self.__current_track_id = None
            self.__current_request_id = ""
            self.__current_stream_spec = None
            self.__init_in_progress = True
            self.__initializing_track_id = None
            self.__initializing_request_id = release_id
            self.__init_event.clear()
        try:
            self.__terminate_streaming()
            released_resources = release_resources(released_spec)
        finally:
            with self.__stream_lock:
                if self.__initializing_request_id == release_id:
                    self.__init_in_progress = False
                    self.__initializing_request_id = ""
                    self.__init_event.set()
        return released_track or bool(released_resources)

    def __terminate_streaming(self) -> None:
        if self.__spotty_streamer.terminate_stream():
            log_msg("Terminated running streamer.", LOGDEBUG)
        else:
            log_msg("No running streamer. Nothing to terminate.", LOGDEBUG)

    def _restore_previous_stream_state(
        self,
        previous_track_id: Optional[str],
        previous_request_id: str,
        previous_was_streaming: bool,
        previous_stream_spec: Optional[SpottyStreamSpec],
        initializing_request_id: Optional[str] = None,
    ) -> None:
        with self.__stream_lock:
            if initializing_request_id is not None and (
                not self.__init_in_progress
                or self.__initializing_request_id != initializing_request_id
            ):
                return
            self.__is_streaming = previous_was_streaming
            self.__current_track_id = previous_track_id
            self.__current_request_id = previous_request_id
            self.__current_stream_spec = previous_stream_spec
            if previous_stream_spec is not None:
                self.__spotty_streamer.restore_stream_spec(previous_stream_spec)
            self.__init_in_progress = False
            self.__initializing_track_id = None
            self.__initializing_request_id = ""
            try:
                self.__init_event.set()
            except Exception:
                pass

    def _find_downloader(self, track_id: str, request_byte: int = 0, stream_spec=None):
        try:
            from spotty_cache import SpottyCacheManager

            return SpottyCacheManager.find_best_downloader(
                track_id, request_byte, stream_spec or self.__current_stream_spec, self.__spotty,
            )
        except Exception:
            return None

    def _find_active_downloader(self, track_id: str):
        """Find a live track downloader without imposing range readability."""
        try:
            from spotty_cache import SpottyCacheManager

            finder = getattr(SpottyCacheManager, "find_active_downloader", None)
            if callable(finder):
                return finder(track_id, self.__current_stream_spec, self.__spotty)
            # Compatibility for older test doubles; production managers expose
            # the trim-independent API above.
            return SpottyCacheManager.find_best_downloader(track_id, 0)
        except Exception:
            return None

    @staticmethod
    def _request_range_begin(request_range: str) -> int:
        """Return a conservative byte offset for same-track health lookup."""
        try:
            value = (request_range or "").strip()
            if not value or not value.startswith("bytes="):
                return 0
            start = value.split("bytes=", 1)[1].split("-", 1)[0].strip()
            return max(0, int(start)) if start else 0
        except (ValueError, IndexError):
            return 0

    @staticmethod
    def _parse_byte_range(request_range: str, file_size: int) -> Optional[Tuple[int, int]]:
        """Parse a single ``bytes=`` range into ``(begin, end_exclusive)``.

        The last-byte-pos is inclusive (RFC 7233): ``bytes=0-99`` is 100 bytes.
        Open-ended ``bytes=N-`` (what Kodi normally sends) runs to the end.
        Returns None when unsatisfiable (first-byte-pos >= size, or an empty
        suffix). Malformed ranges fall back to the whole file.
        """
        try:
            spec = (request_range or "").strip().split("bytes=", 1)[1]
            start_s, end_s = (part.strip() for part in spec.split("-", 1))
            if not start_s:
                if not end_s.isdigit():
                    raise ValueError(request_range)
                suffix = int(end_s)
                if suffix <= 0 or file_size <= 0:
                    return None
                return max(0, file_size - suffix), file_size
            range_begin = int(start_s)
            if range_begin < 0:
                raise ValueError(request_range)
            if range_begin >= file_size:
                return None
            if end_s.isdigit():
                last_byte = int(end_s)
                if last_byte < range_begin:
                    raise ValueError(request_range)
                return range_begin, min(last_byte + 1, file_size)
            return range_begin, file_size
        except (ValueError, IndexError):
            return 0, file_size

    @staticmethod
    def _range_not_satisfiable_response(request_range: str, file_size: int):
        bottle.response.status = 416
        bottle.response.content_type = "text/plain"
        bottle.response.content_length = 0
        bottle.response.headers["Accept-Ranges"] = "bytes"
        bottle.response.headers["Content-Range"] = f"bytes */{file_size}"
        log_msg(
            f"Range '{request_range}' not satisfiable for {file_size} bytes; returning 416.",
            LOGDEBUG,
        )
        return ""

    @staticmethod
    def _downloader_has_real_pcm(downloader) -> bool:
        if downloader is None:
            return False

        has_real_pcm = getattr(downloader, "has_real_pcm", None)
        if callable(has_real_pcm):
            try:
                return bool(has_real_pcm())
            except Exception:
                pass

        cond = getattr(downloader, "cond", None)
        if cond is None:
            return False
        try:
            with cond:
                if bool(getattr(downloader, "error", False)) or bool(
                    getattr(downloader, "aborted", False)
                ):
                    return False
                written = int(getattr(downloader, "written_bytes", 0) or 0)
                start_byte = int(getattr(downloader, "start_byte", 0) or 0)
                wav_header = getattr(downloader, "wav_header", b"") or b""
                header_bytes_in_buffer = max(0, len(wav_header) - start_byte)
                return written > header_bytes_in_buffer
        except Exception:
            return False

    @classmethod
    def _downloader_has_healthy_progress(cls, downloader) -> bool:
        if not cls._downloader_has_real_pcm(downloader):
            return False

        cond = getattr(downloader, "cond", None)
        if cond is None:
            return False
        try:
            with cond:
                if bool(getattr(downloader, "error", False)) or bool(
                    getattr(downloader, "aborted", False)
                ):
                    return False
                if bool(getattr(downloader, "is_finished", False)):
                    return True
        except Exception:
            return False

        has_recent_progress = getattr(downloader, "has_recent_progress", None)
        if callable(has_recent_progress):
            try:
                return bool(has_recent_progress(HEALTHY_PROGRESS_MAX_IDLE_SECONDS))
            except Exception:
                return False

        # Older downloader implementations do not expose progress timestamps.
        # Real PCM plus a non-error active state is the strongest safe fallback.
        return True

    @staticmethod
    def _downloader_is_paused(downloader) -> bool:
        # Kodi's next range request often finds no reader attached: a parked
        # writer is idle, and restarting it would seek Spotty mid-track.
        is_paused = getattr(downloader, "is_paused", None)
        try:
            return callable(is_paused) and bool(is_paused())
        except Exception:
            return False

    def _previous_downloader_finished_for_handoff(
        self,
        previous_track_id: str,
        next_track_id: str,
    ) -> bool:
        downloader = self._find_active_downloader(previous_track_id)
        if downloader is None:
            log_msg(
                f"QueueNextFileEx handoff blocked: no active downloader found for "
                f"{previous_track_id} before {next_track_id}.",
                LOGDEBUG,
            )
            return False

        try:
            with downloader.cond:
                finished_cleanly = (
                    bool(getattr(downloader, "is_finished", False))
                    and not bool(getattr(downloader, "error", False))
                    and not bool(getattr(downloader, "aborted", False))
                )
        except Exception:
            finished_cleanly = False

        if finished_cleanly:
            finished_cleanly = self._downloader_has_real_pcm(downloader)

        reader_paused = False
        if not finished_cleanly:
            # With writer backpressure a healthy downloader no longer finishes
            # early in the track: it pauses ~16 MiB ahead of its reader and only
            # completes during the last ~70-95 s of playback.  Before
            # backpressure, a mid-track request for another track (manual skip
            # while Kodi still reports the old track) almost always found the
            # old download complete and was allowed through.  Keep that
            # behaviour: a downloader paused by an attached reader is healthy
            # and is safe to hand off.  Kodi's natural QueueNextFileEx preload
            # (~5 s before the end) still finds the download complete.
            is_reader_paused = getattr(downloader, "is_reader_paused", None)
            if callable(is_reader_paused):
                try:
                    reader_paused = bool(is_reader_paused())
                except Exception:
                    reader_paused = False
            if reader_paused:
                reader_paused = self._downloader_has_real_pcm(downloader)

        if finished_cleanly:
            log_msg(
                f"QueueNextFileEx detected: {previous_track_id} download complete, "
                f"not terminating stream -- letting generator drain for seamless "
                f"transition to {next_track_id}.",
                LOGDEBUG,
            )
        elif reader_paused:
            log_msg(
                f"QueueNextFileEx handoff allowed: {previous_track_id} downloader is "
                f"healthy and paused by its reader (backpressure) before {next_track_id}.",
                LOGDEBUG,
            )
            return True
        else:
            log_msg(
                f"QueueNextFileEx handoff deferred without waiting: {previous_track_id} "
                f"is still active before {next_track_id}.",
                LOGDEBUG,
            )
        return finished_cleanly

    def _previous_stream_has_confirmed_playback(self, previous_track_id: str) -> bool:
        downloader = self._find_active_downloader(previous_track_id)
        if not self._downloader_has_healthy_progress(downloader):
            log_msg(
                f"Discarding stale Spotify stream guard for {previous_track_id}: "
                f"the prior downloader has no healthy real-PCM progress.",
                LOGDEBUG,
            )
            return False

        try:
            has_active_audio = bool(xbmc.getCondVisibility("Player.HasAudio"))
            if not has_active_audio:
                log_msg(
                    f"Discarding stale Spotify stream guard for {previous_track_id}: "
                    f"Kodi has no active audio playback.",
                    LOGDEBUG,
                )
                return False

            win = xbmcgui.Window(ADDON_WINDOW_ID)
            confirmed_track_id = (win.getProperty("Spotify.CurrentTrackId") or "").strip()
            if confirmed_track_id:
                if confirmed_track_id == previous_track_id:
                    return True
                log_msg(
                    f"Discarding stale Spotify stream guard for {previous_track_id}: "
                    f"Kodi confirms {confirmed_track_id} instead.",
                    LOGDEBUG,
                )
                return False

            file_url = xbmc.getInfoLabel("Player.Filenameandpath") or ""
            if f"/track/{previous_track_id}/" in file_url:
                return True

            log_msg(
                f"Discarding stale Spotify stream guard for {previous_track_id}: "
                f"no Kodi-confirmed active Spotify playback.",
                LOGDEBUG,
            )
            return False
        except Exception:
            return False

    def _coordinate_initialization(
        self,
        track_id: str,
        request_id: str,
        request_byte: int = 0,
        stream_spec=None,
    ):
        deadline = time.monotonic() + INITIALIZATION_WAIT_SECONDS
        while True:
            wait_event = None
            reuse_request_id = None
            with self.__stream_lock:
                if self.__init_in_progress:
                    wait_event = self.__init_event
                    initializing_track_id = self.__initializing_track_id
                elif self.__is_streaming and self.__current_track_id == track_id:
                    # Check downloader health outside __stream_lock. Cache lookup
                    # and downloader.cond must never be nested under this lock.
                    reuse_request_id = self.__current_request_id
                else:
                    previous_track_id = self.__current_track_id
                    previous_request_id = self.__current_request_id
                    previous_was_streaming = self.__is_streaming
                    previous_stream_spec = self.__current_stream_spec
                    self.__init_in_progress = True
                    self.__initializing_track_id = track_id
                    self.__initializing_request_id = request_id
                    self.__init_event.clear()
                    return (
                        True,
                        request_id,
                        previous_track_id,
                        previous_request_id,
                        previous_was_streaming,
                        previous_stream_spec,
                        None,
                    )

            if reuse_request_id is not None:
                downloader = self._find_downloader(track_id, request_byte, stream_spec)
                healthy = self._downloader_has_healthy_progress(
                    downloader
                ) or self._downloader_is_paused(downloader)
                with self.__stream_lock:
                    # State may have changed while downloader health was checked.
                    # Retry coordination instead of acting on a stale snapshot.
                    if (
                        self.__init_in_progress
                        or not self.__is_streaming
                        or self.__current_track_id != track_id
                        or self.__current_request_id != reuse_request_id
                    ):
                        continue
                    if healthy:
                        current_stream_spec = self.__current_stream_spec
                        return (
                            False,
                            reuse_request_id,
                            self.__current_track_id,
                            reuse_request_id,
                            self.__is_streaming,
                            current_stream_spec,
                            current_stream_spec,
                        )

                    previous_track_id = self.__current_track_id
                    previous_request_id = self.__current_request_id
                    previous_was_streaming = self.__is_streaming
                    previous_stream_spec = self.__current_stream_spec
                    self.__init_in_progress = True
                    self.__initializing_track_id = track_id
                    self.__initializing_request_id = request_id
                    self.__init_event.clear()

                cleanup = getattr(downloader, "cleanup", None)
                if callable(cleanup):
                    try:
                        cleanup()
                    except Exception:
                        pass
                log_msg(
                    f"Reinitializing {track_id}: the current downloader is missing, "
                    "failed, or no longer making healthy real-PCM progress.",
                    LOGDEBUG,
                )
                return (
                    True,
                    request_id,
                    previous_track_id,
                    previous_request_id,
                    previous_was_streaming,
                    previous_stream_spec,
                    None,
                )

            log_msg(
                f"Initialization for {initializing_track_id} already in progress; "
                f"waiting before serving {track_id}.",
                LOGDEBUG,
            )
            remaining = deadline - time.monotonic()
            if remaining <= 0 or not wait_event.wait(timeout=remaining):
                return None

    def _prepare_initialization(
        self,
        track_id: str,
        request_id: str,
        duration: float,
        bitrate: str,
        normalization: str,
    ) -> Optional[SpottyStreamSpec]:
        """Configure the shared streamer without publishing readiness.

        The initialization reservation remains held while the caller performs
        eager downloader preflight. Concurrent GETs therefore cannot reuse the
        track or commit response headers before real PCM is ready.
        """
        with self.__stream_lock:
            if (
                not self.__init_in_progress
                or self.__initializing_track_id != track_id
                or self.__initializing_request_id != request_id
            ):
                return None
            self.__spotty_streamer.bitrate = bitrate
            self.__spotty_streamer.normalization_gain_type = normalization
            self.__spotty_streamer.set_track(track_id, duration)
            return self.__spotty_streamer.get_stream_spec()

    def _commit_initialization(
        self,
        track_id: str,
        request_id: str,
        stream_spec: SpottyStreamSpec,
    ) -> bool:
        """Publish a preflighted stream and release same-track waiters."""
        with self.__stream_lock:
            if (
                not self.__init_in_progress
                or self.__initializing_track_id != track_id
                or self.__initializing_request_id != request_id
            ):
                return False
            self.__is_streaming = True
            self.__current_track_id = track_id
            self.__current_request_id = request_id
            self.__current_stream_spec = stream_spec
            self.__init_in_progress = False
            self.__initializing_track_id = None
            self.__initializing_request_id = ""
            self.__init_event.set()
            return True

    def _owns_initialization(self, track_id: str, request_id: str) -> bool:
        """Return whether this request still owns the unpublished init reservation."""
        with self.__stream_lock:
            return (
                self.__init_in_progress
                and self.__initializing_track_id == track_id
                and self.__initializing_request_id == request_id
            )

    def _abort_initialization(
        self,
        track_id: str,
        request_id: str,
        previous_track_id: Optional[str],
        previous_request_id: str,
        previous_was_streaming: bool,
        previous_stream_spec: Optional[SpottyStreamSpec],
        previous_stream_preserved: bool,
    ) -> None:
        """Release an owned reservation and restore only a preserved stream."""
        with self.__stream_lock:
            if (
                not self.__init_in_progress
                or self.__initializing_track_id != track_id
                or self.__initializing_request_id != request_id
            ):
                return
            self.__is_streaming = previous_was_streaming and previous_stream_preserved
            self.__current_track_id = previous_track_id
            self.__current_request_id = previous_request_id
            self.__current_stream_spec = previous_stream_spec if previous_stream_preserved else None
            if previous_stream_preserved and previous_stream_spec is not None:
                self.__spotty_streamer.restore_stream_spec(previous_stream_spec)
            self.__init_in_progress = False
            self.__initializing_track_id = None
            self.__initializing_request_id = ""
            self.__init_event.set()

    @staticmethod
    def _unavailable_response(message: str):
        """Refuse a stream request with 503; Kodi skips the track on a refusal.

        Logged without debug logging: a refusal chain is a user-visible skip.
        """
        bottle.response.status = 503
        bottle.response.content_type = "text/plain"
        bottle.response.content_length = 0
        bottle.response.headers["Retry-After"] = "1"
        log_msg(message, LOGWARNING)
        return ""

    def _initialization_busy_response(self, track_id: str, reason: str):
        with self.__stream_lock:
            owner = (
                self.__initializing_track_id or "a stream release"
                if self.__init_in_progress
                else "none"
            )
        return self._unavailable_response(
            f"Refusing stream for {track_id}: {reason} (startup owner: {owner})."
        )

    def _player_near_natural_handoff(self, previous_track_id: str) -> bool:
        try:
            if not xbmc.getCondVisibility("Player.HasAudio"):
                return False
            file_url = xbmc.getInfoLabel("Player.Filenameandpath") or ""
            if f"/track/{previous_track_id}/" not in file_url:
                return False

            elapsed = _parse_time_label(xbmc.getInfoLabel("MusicPlayer.Time"))
            duration = _parse_time_label(xbmc.getInfoLabel("MusicPlayer.Duration"))
            if elapsed is None or duration is None or duration <= 0:
                return False

            remaining = duration - elapsed
            return remaining <= NATURAL_HANDOFF_REMAINING_SECONDS
        except Exception:
            return False

    def _busy_with_current_track_response(
        self,
        previous_track_id: Optional[str],
        previous_request_id: str,
        previous_was_streaming: bool,
        previous_stream_spec: Optional[SpottyStreamSpec],
        next_track_id: str,
        initializing_request_id: str,
    ):
        self._restore_previous_stream_state(
            previous_track_id,
            previous_request_id,
            previous_was_streaming,
            previous_stream_spec,
            initializing_request_id,
        )
        return self._unavailable_response(
            f"Refusing preload for {next_track_id}: active Spotify stream "
            f"{previous_track_id} is not safely complete."
        )

    def _notify_playback_failure(self, track_id: str, force: bool = False) -> None:
        cause = None
        try:
            from spotty_cache import SpottyCacheManager

            cause = SpottyCacheManager.get_failure_cause(track_id)
        except (ImportError, AttributeError):
            pass
        if cause is None and not force:
            return
        try:
            session = xbmcgui.Window(ADDON_WINDOW_ID).getProperty("Spotify.PlayQueue.SessionId")
            now = time.monotonic()
            with self._failure_notice_lock:
                previous_session, previous_time = self._last_failure_notice
                if previous_session == session and (session or now - previous_time < 60):
                    return
                self._last_failure_notice = (session, now)
            addon = xbmcaddon.Addon(id=ADDON_ID)
            string_id = {
                "auth": SPOTIFY_PLAYBACK_AUTH_STR_ID,
                "premium": SPOTIFY_PLAYBACK_PREMIUM_STR_ID,
            }.get(cause, SPOTIFY_PLAYBACK_FAILED_STR_ID)
            xbmcgui.Dialog().notification(
                addon.getAddonInfo("name"),
                addon.getLocalizedString(string_id),
                icon=addon.getAddonInfo("icon"),
                time=5000,
                sound=False,
            )
        except Exception as exc:
            log_msg(f"Spotify playback notification failed ({type(exc).__name__}).", LOGWARNING)

    def _failed_new_track_response(
        self,
        track_id: str,
        request_id: str,
        previous_track_id: Optional[str],
        previous_request_id: str,
        previous_was_streaming: bool,
        previous_stream_spec: Optional[SpottyStreamSpec],
        previous_stream_preserved: bool,
    ):
        notify_failure = self._owns_initialization(track_id, request_id)
        self._abort_initialization(
            track_id,
            request_id,
            previous_track_id,
            previous_request_id,
            previous_was_streaming,
            previous_stream_spec,
            previous_stream_preserved,
        )
        if notify_failure:
            self._notify_playback_failure(track_id, force=True)
        return self._unavailable_response(
            f"Refusing stream for {track_id}: Spotty failed before real PCM "
            f"(previous={previous_track_id}, previous_streaming={previous_was_streaming})."
        )

    SPOTTY_AUDIO_TRACK_ROUTE = "/track/<track_id>/<duration>"

    def spotty_stream_audio_track(self, track_id: str, duration: str) -> bottle.Response:
        # .xwav marks the item as audio without the empty WAV TagLib probe; MIME selects the codec.
        # Normalize saved decimal-second URLs and canonical milliseconds before HEAD/GET.
        try:
            if re.fullmatch(r"[0-9]+ms\.xwav", duration):
                duration = int(duration[:-7]) / 1000.0
            elif re.fullmatch(r"[0-9]+(?:\.[0-9]+)?(?:\.wav)?", duration):
                duration = float(duration[:-4] if duration.endswith(".wav") else duration)
            else:
                raise ValueError("Invalid track duration")
            if not math.isfinite(duration):
                raise ValueError("Invalid track duration")
            duration = max(1.0, duration)
        except (ValueError, OverflowError):
            bottle.response.status = 400
            return "Invalid track duration."
        log_msg(f"{bottle.request.method} request: {bottle.request}", LOGDEBUG)

        # HEAD requests: return headers only. NEVER mutate state, call set_track(),
        # overwrite __current_request_id, or fire on_track_started. HEAD probes must
        # be invisible to the streaming pipeline.
        if bottle.request.method.upper() != "GET":
            return self._handle_head_only(track_id, duration)

        # Generate unique request ID for coordinating concurrent init requests.
        request_id = str(uuid.uuid4())

        # Read settings FIRST.
        bitrate, norm = _get_current_stream_settings()
        wav_header, track_length = create_wav_header_for_duration(duration)
        desired_spec = SpottyStreamSpec(
            track_id, duration, wav_header, track_length, bitrate, norm,
            self.__spotty_streamer.initial_volume,
        )

        request_range = bottle.request.headers.get("Range", "")
        coordination = self._coordinate_initialization(
            track_id,
            request_id,
            self._request_range_begin(request_range),
            desired_spec,
        )
        if coordination is None:
            return self._initialization_busy_response(
                track_id,
                f"another startup did not finish within {INITIALIZATION_WAIT_SECONDS:.0f}s",
            )
        (
            is_new_track,
            request_id,
            _previous_track_id,
            _previous_request_id,
            _previous_was_streaming,
            _previous_stream_spec,
            request_stream_spec,
        ) = coordination
        previous_stream_preserved = bool(_previous_was_streaming)

        try:
            # Fetch prebuffer result (WAV bytes if prebuffer was used).
            prebuf_result = None
            has_prebuf = False
            if is_new_track and self.__prebuffer_manager:
                prebuf_result, has_prebuf = self.__prebuffer_manager.get_and_clear_prebuffer(
                    track_id, desired_spec,
                )
                if has_prebuf:
                    kind = f"{len(prebuf_result.data)} bytes"
                    log_msg(f"Prebuffer hit for track {track_id} ({kind}).", LOGDEBUG)

            if is_new_track:
                # Cancel any running prebuffer immediately so its spotty process doesn't
                # compete with the main stream for the single Spotify connection.  A
                # prebuffer from the *previous* track selection may still be running
                # (the 5-second deferred start in main_service only delays the *next*
                # prebuffer, it doesn't cancel an already-running one).
                if self.__prebuffer_manager:
                    self.__prebuffer_manager.cancel_prebuffer()

                # Terminate the previous track's stream — unless this is Kodi's QueueNextFileEx
                # pre-load (new track ID while the previous track's download is already complete
                # in the cache).  In that case, killing the HTTP generator cuts the current track
                # ~5 seconds short; let it drain naturally instead.  send_part_audio_stream()
                # captures its track-specific state at entry, so two generators running briefly
                # in parallel read from independent cache entries without interfering.
                # New-track requests may arrive before the next decoder is actually ready
                # (QueueNextFileEx can update player metadata early). Protect a healthy
                # active stream, but never hold the HTTP worker waiting for it to finish.
                _skip_terminate = False
                if (
                    _previous_track_id
                    and _previous_track_id != track_id
                    and _previous_was_streaming
                ):
                    if self._player_near_natural_handoff(_previous_track_id):
                        log_msg(
                            f"QueueNextFileEx natural handoff allowed: Kodi is near the end of "
                            f"{_previous_track_id}, so {track_id} may start.",
                            LOGDEBUG,
                        )
                        _skip_terminate = True
                    elif not self._previous_stream_has_confirmed_playback(_previous_track_id):
                        log_msg(
                            f"Starting {track_id}: previous stream {_previous_track_id} "
                            f"is stale or has no healthy real-PCM progress.",
                            LOGDEBUG,
                        )
                    elif self._previous_downloader_finished_for_handoff(
                        _previous_track_id,
                        track_id,
                    ):
                        _skip_terminate = True
                    else:
                        return self._busy_with_current_track_response(
                            _previous_track_id,
                            _previous_request_id,
                            _previous_was_streaming,
                            _previous_stream_spec,
                            track_id,
                            request_id,
                        )
                if not _skip_terminate:
                    # Once termination begins, restoration is unsafe even if the
                    # termination call itself raises after partially taking effect.
                    previous_stream_preserved = False
                    self.__terminate_streaming()

                request_stream_spec = self._prepare_initialization(
                    track_id,
                    request_id,
                    duration,
                    bitrate,
                    norm,
                )
                if request_stream_spec is None:
                    return self._initialization_busy_response(
                        track_id, "this startup was replaced"
                    )
                log_msg(
                    f"Preparing spotify track '{track_id}',"
                    f" track length {request_stream_spec.track_length}."
                )

                # Kodi may issue this GET for QueueNextFileEx/preload before audible
                # playback starts. MainService publishes Spotify.CurrentTrack* only
                # after xbmc.Player confirms active Spotify playback.

            log_msg(f"Request header range: '{request_range}'.", LOGDEBUG)

            if request_stream_spec is None:
                # Compatibility for restored state created before immutable stream
                # specs existed. Normal initialized streams always carry one.
                request_stream_spec = self.__spotty_streamer.get_stream_spec()

            return self._handle_wav_request(
                is_new_track,
                request_range,
                prebuf_result,
                has_prebuf,
                track_id=track_id,
                duration_sec=duration,
                request_id=request_id,
                previous_track_id=_previous_track_id,
                previous_request_id=_previous_request_id,
                previous_was_streaming=_previous_was_streaming,
                previous_stream_spec=_previous_stream_spec,
                previous_stream_preserved=previous_stream_preserved,
                stream_spec=request_stream_spec,
            )
        except Exception:
            # Unexpected failures before commit must not strand the coordinator
            # with a cleared event. Preserve Bottle's normal exception handling
            # by rolling back only our still-owned reservation, then re-raising.
            if is_new_track and self._owns_initialization(track_id, request_id):
                self._abort_initialization(
                    track_id,
                    request_id,
                    _previous_track_id,
                    _previous_request_id,
                    _previous_was_streaming,
                    _previous_stream_spec,
                    previous_stream_preserved,
                )
            raise

    spotty_stream_audio_track.route = SPOTTY_AUDIO_TRACK_ROUTE

    def _handle_head_only(self, track_id: str, duration: float):
        """Return headers for HEAD requests without touching any streaming state."""
        # Always derive size from the URL's duration — the current streamer may have a
        # different track loaded, which would return the wrong Content-Length for queued
        # (non-current) tracks and confuse Kodi's prefetch queue.
        _, file_size = create_wav_header_for_duration(duration)

        bottle.response.status = 200
        bottle.response.content_type = "audio/x-wav"
        bottle.response.content_length = file_size
        bottle.response.headers["Accept-Ranges"] = "bytes"

        log_msg(
            f"HEAD response: track={track_id}, content_length={bottle.response.content_length}",
            LOGDEBUG,
        )
        return ""

    # ------------------------------------------------------------------
    #  WAV (PCM) path — standard HTTP range semantics
    # ------------------------------------------------------------------

    def _handle_wav_request(
        self,
        is_new_track,
        request_range,
        prebuf_result,
        has_prebuf,
        track_id=None,
        duration_sec=1.0,
        request_id=None,
        previous_track_id=None,
        previous_request_id="",
        previous_was_streaming=False,
        previous_stream_spec=None,
        previous_stream_preserved=False,
        stream_spec=None,
    ):
        streamer = self.__spotty_streamer
        stream_spec = stream_spec or streamer.get_stream_spec()
        file_size = stream_spec.track_length
        range_begin = 0
        range_end = file_size
        is_seek = False

        # Only call set_track if this is a new track or file_size is invalid.
        # For new tracks, set_track() was already called in spotty_stream_audio_track() inside the lock.
        # This is just a safety net for recovery if file_size is invalid.
        if (file_size <= 0 or file_size < 50000) and track_id:
            # Compute WAV header length without mutating shared streamer state to
            # ensure HEAD/early requests can return accurate Content-Length.
            try:
                _, total_length = create_wav_header_for_duration(duration_sec)
                file_size = total_length
                range_end = file_size
                log_msg(
                    f"Computed WAV header length from duration={duration_sec}s -> file_size={file_size}.",
                    LOGDEBUG,
                )
            except Exception:
                pass

        prebuf_data = prebuf_result.data if (has_prebuf and prebuf_result) else None

        if not request_range or (request_range == "bytes=0-"):
            status = 200
            content_range = ""
            log_msg(f"Full request, content length = {range_end - range_begin}.", LOGDEBUG)
        else:
            status = "206 Partial Content"
            byte_range = self._parse_byte_range(request_range, file_size)
            if byte_range is None:
                if is_new_track:
                    self._abort_initialization(
                        track_id or "",
                        request_id or "",
                        previous_track_id,
                        previous_request_id,
                        previous_was_streaming,
                        previous_stream_spec,
                        previous_stream_preserved,
                    )
                return self._range_not_satisfiable_response(request_range, file_size)
            range_begin, range_end = byte_range
            # Content-Range end is inclusive — use range_end - 1
            content_range = f"bytes {range_begin}-{range_end - 1}/{file_size}"
            if not is_new_track and range_begin > 0:
                is_seek = True
            # User selected a different track (e.g. from playlist while one was playing).
            # Kodi may send a stale Range—serve from start. Use a tiny first chunk (256 bytes)
            # so the first response returns immediately (UI snappy); Kodi then requests the
            # rest using its cache.chunksize for everything after.
            if is_new_track and range_begin > 0:
                # "prev" or stale range: Kodi sends bytes=44- (WAV header size) to
                # restart from the first PCM byte, or carries over a mid-track range
                # from a previous track.  Honor the requested byte offset exactly —
                # Kodi uses CURLOPT_RESUME_FROM which enforces that the server starts
                # at the requested byte, so returning any other range causes error 33.
                # send_part_audio_stream throttles range_begin <= WAV_HEADER_SIZE (44)
                # at real-time rate, keeping the connection alive for QueueNextFileEx.
                log_msg(
                    f"New track request with range_begin={range_begin} (restart/stale), serving from that byte.",
                    LOGDEBUG,
                )
            log_msg(
                f"Partial request, range = {content_range}," f" length = {range_end - range_begin}",
                LOGDEBUG,
            )

        with self.__stream_lock:
            owns_response = (
                self.__initializing_request_id == request_id if is_new_track
                else not self.__init_in_progress and self.__current_request_id == request_id
            )
            response_generation = streamer.get_stream_generation()
        if not owns_response:
            return self._unavailable_response("Spotify response was replaced before audio admission.")
        downloader = streamer._get_or_start_downloader(stream_spec, range_begin, response_generation)
        if downloader is None or not downloader.identity_valid():
            if downloader is not None:
                downloader.cleanup()
            if is_new_track:
                return self._failed_new_track_response(
                    track_id or "", request_id or "", previous_track_id,
                    previous_request_id, previous_was_streaming,
                    previous_stream_spec, previous_stream_preserved,
                )
            return self._unavailable_response("Spotify audio identity changed before response headers.")

        if bottle.request.method.upper() == "GET" and is_new_track and not prebuf_data:
            if not streamer.prepare_part_audio_stream(
                range_begin, stream_spec=stream_spec, downloader=downloader,
                stream_generation=response_generation,
            ):
                return self._failed_new_track_response(
                    track_id or "",
                    request_id or "",
                    previous_track_id,
                    previous_request_id,
                    previous_was_streaming,
                    previous_stream_spec,
                    previous_stream_preserved,
                )

        if streamer._is_terminated(response_generation) or not downloader.identity_valid():
            if not streamer._is_terminated(response_generation):
                downloader.cleanup()
            if is_new_track:
                self._abort_initialization(
                    track_id or "", request_id or "", previous_track_id,
                    previous_request_id, previous_was_streaming,
                    previous_stream_spec, previous_stream_preserved,
                )
            return self._unavailable_response("Spotify audio identity changed before response headers.")

        if is_new_track and not self._commit_initialization(
            track_id or "",
            request_id or "",
            stream_spec,
        ):
            return self._initialization_busy_response(
                track_id or "", "this startup was replaced"
            )

        r_begin = range_begin
        r_end = range_end
        r_len = r_end - r_begin
        prebuffer_prefix = b""
        stream_body = None
        if prebuf_data:
            prebuffer_len = len(prebuf_data)
            if r_begin < prebuffer_len:
                end_from_buf = min(r_end, prebuffer_len)
                prebuffer_prefix = prebuf_data[r_begin:end_from_buf]
            if r_end > prebuffer_len:
                rest_begin = max(r_begin, prebuffer_len)
                rest_len = r_end - rest_begin
                stream_body = streamer.send_part_audio_stream(
                    rest_len,
                    rest_begin,
                    stream_spec=stream_spec,
                    downloader=downloader,
                    stream_generation=response_generation,
                )
        else:
            stream_body = streamer.send_part_audio_stream(
                r_len,
                r_begin,
                stream_spec=stream_spec,
                downloader=downloader,
                stream_generation=response_generation,
            )

        def generate():
            try:
                if is_seek:
                    # Do NOT terminate the active stream on seek. Kodi opens multiple connections
                    # (e.g. GET bytes=0- then GET bytes=20- after reading WAV header). Terminating
                    # here closed the first connection prematurely, causing "Transferred a partial
                    # file" and "Open - Unhandled exception". Both connections can read from cache.
                    log_msg(
                        f"Seek to byte {range_begin}, streaming from cache (parallel read, no terminate).",
                        LOGDEBUG,
                    )
                elif is_new_track:
                    # Previous track already terminated in spotty_stream_audio_track();
                    # do not terminate here or a second GET for this track would kill the first.
                    log_msg(
                        "New track: streaming from cache (previous stream already terminated).",
                        LOGDEBUG,
                    )

                if prebuffer_prefix:
                    yield prebuffer_prefix
                if stream_body is not None:
                    yield from stream_body
                with self.__stream_lock:
                    owns_stream = self.__current_request_id == request_id
                if owns_stream:
                    self._notify_playback_failure(track_id or "")
            except GeneratorExit:
                # Back can mean "close OSD" (playback continues) or "cancel". Do NOT clear
                # state here—we only clear when the track truly ends (__notify_track_finished).
                # Next range request will still see same track; "from start" requests always re-init.
                raise
            except (BrokenPipeError, ConnectionResetError, OSError):
                # Pipe/connection error: do NOT clear state here. This often happens when
                # we kill the stream for a seek (another request called __terminate_streaming);
                # clearing would make the next request look like a new track and cause
                # desync, no audio, and skip storms. Only GeneratorExit means client left.
                log_msg(
                    "Stream read/write error, not clearing state.",
                    LOGDEBUG,
                )
                raise

        bottle.response.status = status
        bottle.response.headers["Accept-Ranges"] = "bytes"
        bottle.response.content_type = "audio/x-wav"
        bottle.response.content_length = range_end - range_begin
        if content_range:
            bottle.response.headers["Content-Range"] = content_range

        if bottle.request.method.upper() == "GET":
            return generate()
        return ""

    def toggle_track_like(self, track_id: str) -> bottle.Response:
        """Toggle the liked status of a track in Spotify"""
        try:
            # Get the authentication token
            token = get_valid_cached_auth_token()
            if not token:
                notify_not_connected()
                bottle.response.status = 401
                return "Unauthorized"

            # Create Spotify client
            sp = spotipy.Spotify(auth=token)

            # Check if track is currently liked
            result = sp.current_user_saved_tracks_contains([track_id])
            is_liked = result[0] if result else False

            # Toggle the like status
            if is_liked:
                # Unlike the track
                sp.current_user_saved_tracks_delete([track_id])
                liked_status = ""
            else:
                # Like the track
                sp.current_user_saved_tracks_add([track_id])
                liked_status = "true"

            # Update the window property, unless playback moved on to another track
            win = xbmcgui.Window(ADDON_WINDOW_ID)
            if set_current_track_liked(track_id, bool(liked_status)):
                # Also update the window property to indicate the change occurred
                win.setProperty("Spotify.TrackLikeChanged", "true")

                # Clear the change flag after a short delay to allow UI to react
                def clear_flag():
                    xbmc.sleep(100)
                    win.clearProperty("Spotify.TrackLikeChanged")

                threading.Thread(target=clear_flag, daemon=True).start()

            # Return success response
            bottle.response.content_type = "application/json"
            return {"success": True, "liked": liked_status == "true"}

        except Exception as e:
            log_msg(f"Error toggling track like status: {e}", LOGDEBUG)
            bottle.response.status = 500
            return {"success": False, "error": str(e)}

    toggle_track_like.route = "/toggle_like/<track_id>"
